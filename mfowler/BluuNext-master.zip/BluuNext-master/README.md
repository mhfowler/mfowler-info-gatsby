BluuNext
========

A bold serif typeface with a strong flavour by [Jean-Baptiste Morizot](http://cargocollective.com/jbmorizot/).

BluuNext is available on [Velvetyne Type Foundry](http://velvetyne.fr/fonts/bluu/).


![specimen1](https://github.com/velvetyne/BluuNext/blob/master/Documentation/img/01.jpg)
![specimen2](https://github.com/velvetyne/BluuNext/blob/master/Documentation/img/02.jpg)

## License

Millimetre is licensed under the SIL Open Font License, Version 1.1.
This license is copied below, and is also available with a FAQ at
http://scripts.sil.org/OFL

